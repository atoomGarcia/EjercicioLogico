﻿using System;

namespace MensajeOculto
{
    class Mensaje
    {
        public string Palabra1;
        public int Cant1;
        public string Palabra2;
        public int Cant2;
        public string MensajeCodificado;
        public int CantMnje;
        public string flag="";
        public string letra;
        public string resp1 = "SI";
        public string resp2 = "SI";

        public static void Main()
        {
            Mensaje Mensaje1 = new Mensaje();
            Mensaje1.ElaboraMensaje();
            Console.ReadKey();
        }

        public void ElaboraMensaje()
        {

            Console.Write("Primera palabra : ");
            Palabra1 = Console.ReadLine();
            Cant1 = Palabra1.Length; // NO ES NECESARIO PREGUNTAR POR LA LONGITUD DE LAS PALABRAS.

            if(Cant1 < 2 || Cant1 > 50)
            {
                Console.Write("::::: LOS VALORES DEBN SER ENTRE  2 Y 50 CARACTERES :::::");

                return;

            }
    

            Console.Write("Segunda palabra : ");
            Palabra2 = Console.ReadLine();
            Cant2 = Palabra2.Length;

            if (Cant2 < 2 || Cant2 > 50)
            {
                Console.Write("::::: LOS VALORES DEBN SER ENTRE  2 Y 50 CARACTERES :::::");

                return;

            }

            Console.Write("Mensaje codificado : ");
            MensajeCodificado = Console.ReadLine();
            CantMnje = MensajeCodificado.Length;

            if (CantMnje < 3 || CantMnje > 5000)
            {
                Console.Write("::::: LOS VALORES DEBN SER ENTRE  3 Y 5000 CARACTERES :::::");

                return;

            }

            //// ESTE FOR SIMPLIFICA EL MENSAJE CODIFICADO YA QUE NO SE PERMITEN PALABRAS CON LETRAS CONSECUTIVAS REPETIDAS ////
            for (int i = 0; i < CantMnje; i++)
            {
                letra=MensajeCodificado.Substring(i, 1);
                if (letra == flag)
                {
                    MensajeCodificado=MensajeCodificado.Remove(i, 1);
                    i--;
                    CantMnje--;
                }

                flag = MensajeCodificado.Substring(i, 1);
                
            }

            //// SE PROCEDE A BUSCAR LAS LETRAS DE LAS PALABRAS EN EL MENSAJE SIMPLIFICADO ////
      
            for (int j = 0; j < Cant1; j++)
            {
                if (MensajeCodificado.Contains(Palabra1[j])) 
                {
                    //Console.WriteLine(Palabra1[i] + "   SI");
                }
                else
                {
                    resp1 = "NO";  // SI ALGUNA DE LAS LETRAS DE LA PRIMERA PALABRA NO SE ENCUENTRA CODIFICADA, SE DE POR HECHO QUE LA PALABRA NO SE ENCUENTRA POR LO TANTO SE CAMBIA A "NO" EN LA RESPUESTA //
                }

            }

            for (int k = 0; k < Cant2; k++)
            {
                if (MensajeCodificado.Contains(Palabra2[k]))
                {
                    //Console.WriteLine(Palabra1[i] + "   SI");
                }
                else
                {
                    resp2 = "NO"; // SI ALGUNA DE LAS LETRAS DE LA SEGUNDA PALABRA NO SE ENCUENTRA CODIFICADA, SE DE POR HECHO QUE LA PALABRA NO SE ENCUENTRA POR LO TANTO SE CAMBIA A "NO" EN LA RESPUESTA //
                }

            }

            Console.WriteLine("::::::::::::::::::::::: RESULTADOS :::::::::::::::::::::::");
            Console.WriteLine(resp1);
            Console.WriteLine(resp2);

        }

    }
}
