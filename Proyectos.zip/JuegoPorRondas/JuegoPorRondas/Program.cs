﻿using System;

namespace JuegoPorRondas
{   
    class Juego
    {
        public string Ganador = "es el jugador 1";
        public int Diferencia = 0;
        public int RondaGanada1 = 0;
        public int RondaGanada2 = 0;
        public string Mensaje;


        public static void Main()
        {
            Juego Juego1 = new Juego();
            Juego1.Torneo();
            Console.ReadKey();
        }

        public void Torneo()
        {
            int NumeroRondas;

            Console.Write("Numero de rondas con la que contará el torneo : ");

            try
            {
                NumeroRondas = Convert.ToInt32(Console.ReadLine());

                if (NumeroRondas > 0 && NumeroRondas <= 10000)
                {
                    ConteoDeRondas(NumeroRondas);

                    Console.WriteLine(":::::::::: RESULTADOS ::::::::::");
                    Console.Write("El ganador del torneo {0} con una diferencia de {1}",
                    Ganador, Mensaje);

                }
                else
                {
                    Console.WriteLine(":::::::::: EL NUMERO DE RONDAS DEBE SER MAYOR A 0 Y MENOR O IGUAL A 10000 ::::::::::");
                    Torneo();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(":::::::::: ASEGURESE DE INGRESAR UN NUMERICO E NTENTAR DE NUEVO ::::::::::");
            }                

        }


        public void ConteoDeRondas(int NumeroRondas)
        {
            int ResRonda1 = 0;
            int ResRonda2 = 0;

            int Puntos1;
            int Puntos2;

            for (int i = 1; i <= NumeroRondas; i++)
            {
                
                Console.WriteLine(":::::::::: RONDA " + i + " :::::::::: ");
                Console.Write("Resultados del jugador 1 en la ronda " + i + " : ");
                Puntos1  = Convert.ToInt32(Console.ReadLine());
                ResRonda1 += Puntos1;

                Console.Write("Resultados del jugador 2 en la ronda " + i + " : ");
                Puntos2 = Convert.ToInt32(Console.ReadLine());
                ResRonda2 += Puntos2;

                if (Puntos1 > Puntos2)
                {
                    RondaGanada1++;
                }
                
                if(Puntos1 < Puntos2)
                {
                    RondaGanada2++;
                }

            }

            if (ResRonda1 > ResRonda2)
            {
                Diferencia = ResRonda1 - ResRonda2;
                Mensaje = Diferencia + " puntos ";
            }
            else if(ResRonda1 < ResRonda2)
            {
                Diferencia = ResRonda2 - ResRonda1;
                Ganador = "es el jugador 2";
                Mensaje = Diferencia + " puntos ";
            }
            else
            {
                /* Hay un empate, por lo que decide el ganador por
                el que tenga mayor numero de rondas ganadas */

                if (RondaGanada1 > RondaGanada2)
                {
                    Diferencia = RondaGanada1 - RondaGanada2;
                    Ganador = "es el jugador 1 por numero de rondas ganadas";
                    Mensaje = Diferencia + " rondas ";
                }
                else if (RondaGanada1 < RondaGanada2)
                {
                    Diferencia = RondaGanada2 - RondaGanada1;
                    Ganador = "es el jugador 2 por numero de rondas ganadas";
                    Mensaje = Diferencia + " rondas ";
                }
                else
                {
                    Diferencia = RondaGanada2 - RondaGanada1;
                    Ganador = "no ha sido elegido aun, ya que los jugadores se encuentran";
                    Mensaje = Diferencia + " en puntos y numero de rondas ganadas";
                }

            }
        }
    }
}
